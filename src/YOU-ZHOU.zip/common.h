#ifndef _cs2710_common_h
#define _cs2710_common_h

#include "randomc.h"
#include "Country.h"

/* GLOBALS */
extern TRandomMotherOfAll rnd;
extern Country country;

#endif