#include "common.h"
#include <time.h>

/* GLOBALS */
TRandomMotherOfAll rnd((unsigned)time(NULL));
Country country;
